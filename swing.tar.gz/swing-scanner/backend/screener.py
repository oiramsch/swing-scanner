"""
Polygon.io screener with FilterProfile support and market-regime awareness.
Uses grouped-daily for pre-filtering, then per-ticker OHLCV for indicators.
All I/O is async to avoid blocking the FastAPI event loop.
"""
import asyncio
import json
import logging
from datetime import date, timedelta
from typing import Callable, Optional

import httpx
import pandas as pd
import ta as ta_lib

from backend.config import settings
from backend.database import FilterProfile, get_active_filter

logger = logging.getLogger(__name__)

POLYGON_BASE = "https://api.polygon.io"


def _headers() -> dict:
    return {"Authorization": f"Bearer {settings.polygon_api_key}"}


async def _rate_sleep():
    await asyncio.sleep(settings.polygon_rate_limit_sleep)


# ---------------------------------------------------------------------------
# Grouped Daily Snapshot
# ---------------------------------------------------------------------------

async def fetch_grouped_daily() -> list[dict]:
    """
    Fetch all US stock OHLCV for the most recent trading day in one call.
    Returns [{ticker, close, volume}, ...].
    """
    async with httpx.AsyncClient(timeout=60) as client:
        for days_back in range(1, 6):
            target_date = date.today() - timedelta(days=days_back)
            url = (
                f"{POLYGON_BASE}/v2/aggs/grouped/locale/us/market/stocks"
                f"/{target_date.isoformat()}"
            )
            params = {"adjusted": "true", "include_otc": "false"}
            try:
                resp = await client.get(url, headers=_headers(), params=params)
                resp.raise_for_status()
                data = resp.json()
            except Exception as exc:
                logger.warning("Grouped daily fetch failed for %s: %s", target_date, exc)
                continue

            results = data.get("results", [])
            if not results:
                logger.info("No results for %s (holiday/weekend), trying previous day", target_date)
                continue

            logger.info("Grouped daily (%s): %d total tickers", target_date, len(results))
            return [
                {"ticker": r["T"], "close": r.get("c", 0), "volume": int(r.get("v", 0))}
                for r in results
            ]

    logger.error("Could not find a valid trading day in the last 5 days")
    return []


# ---------------------------------------------------------------------------
# Per-ticker OHLCV
# ---------------------------------------------------------------------------

async def fetch_ohlcv(ticker: str, days: int = 60) -> Optional[pd.DataFrame]:
    end = date.today()
    start = end - timedelta(days=days + 15)
    url = (
        f"{POLYGON_BASE}/v2/aggs/ticker/{ticker}/range/1/day"
        f"/{start.isoformat()}/{end.isoformat()}"
    )
    params = {"adjusted": "true", "sort": "asc", "limit": 120}
    try:
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.get(url, headers=_headers(), params=params)
            resp.raise_for_status()
            data = resp.json()
    except Exception as exc:
        logger.warning("OHLCV fetch failed for %s: %s", ticker, exc)
        return None

    results = data.get("results", [])
    if len(results) < 30:
        return None

    df = pd.DataFrame(results)
    df = df.rename(columns={
        "o": "Open", "h": "High", "l": "Low",
        "c": "Close", "v": "Volume", "t": "timestamp",
    })
    df["Date"] = pd.to_datetime(df["timestamp"], unit="ms").dt.date
    df = df.set_index("Date")[["Open", "High", "Low", "Close", "Volume"]]
    return df.tail(days)


# ---------------------------------------------------------------------------
# Indicator computation
# ---------------------------------------------------------------------------

def compute_indicators(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["SMA_20"] = ta_lib.trend.sma_indicator(df["Close"], window=20)
    df["SMA_50"] = ta_lib.trend.sma_indicator(df["Close"], window=50)
    df["EMA_9"] = ta_lib.trend.ema_indicator(df["Close"], window=9)
    df["RSI_14"] = ta_lib.momentum.rsi(df["Close"], window=14)
    df["ATRr_14"] = ta_lib.volatility.average_true_range(
        df["High"], df["Low"], df["Close"], window=14
    )
    # Volume MA
    df["Vol_MA20"] = df["Volume"].rolling(window=20).mean()
    return df


def get_indicator_snapshot(df: pd.DataFrame) -> dict:
    latest = df.iloc[-1]
    return {
        "close": round(float(latest["Close"]), 2),
        "volume": int(latest["Volume"]),
        "sma20": round(float(latest.get("SMA_20") or 0), 2),
        "sma50": round(float(latest.get("SMA_50") or 0), 2),
        "ema9": round(float(latest.get("EMA_9") or 0), 2),
        "rsi14": round(float(latest.get("RSI_14") or 0), 2),
        "atr14": round(float(latest.get("ATRr_14") or 0), 2),
        "vol_ma20": round(float(latest.get("Vol_MA20") or 0), 2),
    }


# ---------------------------------------------------------------------------
# Filter logic
# ---------------------------------------------------------------------------

def _get_filter_params(fp: Optional[FilterProfile]) -> dict:
    """Extract screening params from FilterProfile or fall back to settings."""
    if fp is None:
        return {
            "price_min": settings.min_price,
            "price_max": 9999.0,
            "avg_volume_min": settings.min_volume,
            "rsi_min": settings.min_rsi,
            "rsi_max": settings.max_rsi,
            "price_above_sma50": True,
            "price_above_sma20": False,
            "volume_multiplier": settings.volume_multiplier,
        }
    return {
        "price_min": fp.price_min,
        "price_max": fp.price_max,
        "avg_volume_min": fp.avg_volume_min,
        "rsi_min": fp.rsi_min,
        "rsi_max": fp.rsi_max,
        "price_above_sma50": fp.price_above_sma50,
        "price_above_sma20": fp.price_above_sma20,
        "volume_multiplier": settings.volume_multiplier,
    }


def passes_filter(df: pd.DataFrame, params: dict, regime: str = "neutral") -> bool:
    if df is None or len(df) < 51:
        return False

    latest = df.iloc[-1]
    close = latest["Close"]
    volume = latest["Volume"]

    if pd.isna(latest.get("SMA_50")) or pd.isna(latest.get("RSI_14")):
        return False

    if close < params["price_min"] or close > params["price_max"]:
        return False
    if volume < params["avg_volume_min"]:
        return False
    if params["price_above_sma50"] and close <= latest["SMA_50"]:
        return False
    if params["price_above_sma20"] and close <= latest["SMA_20"]:
        return False

    rsi = latest["RSI_14"]
    if not (params["rsi_min"] <= rsi <= params["rsi_max"]):
        return False

    # In bear regime: RSI must be below 60 (only pullbacks)
    if regime == "bear" and rsi > 60:
        return False

    avg_vol = df["Volume"].iloc[-20:-1].mean()
    if volume < avg_vol * params["volume_multiplier"]:
        return False

    return True


def pre_filter_snapshot(item: dict, params: dict) -> bool:
    """Quick pre-filter on grouped-daily data (price + volume only)."""
    return (
        item["close"] >= params["price_min"]
        and item["close"] <= params["price_max"]
        and item["volume"] >= params["avg_volume_min"]
    )


# ---------------------------------------------------------------------------
# Main screener
# ---------------------------------------------------------------------------

async def run_screener(
    progress_cb: Optional[Callable] = None,
    regime: str = "neutral",
) -> list[dict]:
    """
    Full async screening pipeline.
    Returns up to max_candidates dicts: {ticker, df, indicators}
    """
    fp = get_active_filter()
    params = _get_filter_params(fp)

    logger.info("Screener starting (regime=%s, filter=%s)…", regime, fp.name if fp else "default")

    if progress_cb:
        progress_cb("snapshot", "Fetching market snapshot…", 0, 0, 0, 2)

    all_tickers = await fetch_grouped_daily()

    if not all_tickers:
        logger.error("No market data — check API key / market hours")
        return []

    # Apply price/volume pre-filter
    pre_candidates = [t for t in all_tickers if pre_filter_snapshot(t, params)]
    total = len(pre_candidates)
    logger.info("Pre-filter: %d → %d tickers pass price/volume", len(all_tickers), total)

    if progress_cb:
        progress_cb("snapshot", f"Snapshot done: {total} candidates to screen", 0, total, 0, 5)

    candidates = []
    processed = 0
    max_candidates = fp.confidence_min if fp else settings.max_candidates
    # Use settings.max_candidates for the cap
    max_cap = settings.max_candidates

    for item in pre_candidates:
        if len(candidates) >= max_cap:
            break

        ticker = item["ticker"]
        processed += 1

        if progress_cb:
            pct = 5 + int((processed / max(total, 1)) * 55)
            progress_cb(
                "screening",
                f"Screening {ticker} ({processed}/{total})",
                processed, total, len(candidates), pct,
            )

        await _rate_sleep()

        try:
            df = await fetch_ohlcv(ticker, days=settings.lookback_days)
            if df is None:
                continue

            df = compute_indicators(df)

            if not passes_filter(df, params, regime=regime):
                continue

            indicators = get_indicator_snapshot(df)
            candidates.append({
                "ticker": ticker,
                "df": df,
                "indicators": indicators,
            })
            logger.info(
                "Candidate #%d: %s (RSI=%.1f, Close=%.2f)",
                len(candidates), ticker, indicators["rsi14"], indicators["close"],
            )

        except Exception as exc:
            logger.warning("Error processing %s: %s", ticker, exc)
            continue

    logger.info("Screener done: %d candidates from %d screened", len(candidates), processed)
    return candidates
